const columns = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
let gridData = [];
let enemyGridData = []; // Окремий масив для радара (пострілів по ворогу)

let currentSelectedShipButton = 0;
let isBoardLocked = false;  
let isMyTurn = false; // Змінна для контролю черговості ходів

let shipRemaining = {
    1: 4,
    2: 3,
    3: 2,
    4: 1
};
let isHorizontal = true;
const buttons = document.querySelectorAll('.inner__button > button');
const readyButton = document.getElementById('readyButton');

// Ініціалізація підключення до сервера
const socket = io('https://prepay-progeny-barrack.ngrok-free.dev');
const myRoomId = 'room-1'; // Тимчасова статична кімната

socket.on('connect', () => {
    socket.emit('join_room', myRoomId);
});

socket.on('game_ready', (message) => {
    console.log(message);
    alert('Суперник підключився! Можна розставляти кораблі.');
});

socket.on('start_shooting', (message) => {
    console.log(message);
    alert('Бій почався! Погнали!');
});

socket.on('waiting_for_opponent', (message) => {
    console.log(message);
});

// Функція відправки готової дошки
function sendReadyStatus() {
    socket.emit('submit_board', { roomId: myRoomId, board: gridData });
}

// Генерація даних для обох дощок
for (let row = 1; row <= 10; row++) { 
    for (let col = 0; col < columns.length; col++) {
        gridData.push({ "Row": row, "Column": columns[col], "Status": 0 });
        enemyGridData.push({ "Row": row, "Column": columns[col], "Status": 0 });
    }
}

// Функція кастомізації клітинок (спільна для обох дощок)
function handleCellCustomization(cell, data) {
    if (data.type === "value") {
        cell.text = " ";
    }
    if (data.value == 0) cell.addClass("cell-water");
    if (data.value == 1) cell.addClass("cell-ship");
    if (data.value == 2) cell.addClass("cell-block");
    if (data.value == 3) cell.addClass("cell-hit");   // Клітинка пораненого/вбитого корабля
    if (data.value == 4) cell.addClass("cell-miss");  // Клітинка з промахом
}

// Таблиця 1: Твоє поле з кораблями
var pivot = new WebDataRocks({
    container: "#wdr-component-playerngrok http 3000",
    toolbar: false,
    report: {
        dataSource: { data: gridData },
        slice: {
            rows: [{ uniqueName: "Row" }],
            columns: [{ uniqueName: "Column" }],
            measures: [{ uniqueName: "Status", aggregation: "none" }]
        },
        options: {
            grid: { showGrandTotals: "off", showTotals: "off", showFilter: false, showHeaders: false }
        },
        tableSizes: {
            columns: [
                { idx: 0, width: 40 }, { idx: 1, width: 40 }, { idx: 2, width: 40 }, { idx: 3, width: 40 }, 
                { idx: 4, width: 40 }, { idx: 5, width: 40 }, { idx: 6, width: 40 }, { idx: 7, width: 40 },
                { idx: 8, width: 40 }, { idx: 9, width: 40 }, { idx: 10, width: 40 }
            ]
        }
    },
    customizeCell: handleCellCustomization
});
        
// Таблиця 2: Поле ворога (Радар)
var pivotEnemy = new WebDataRocks({
    container: "#wdr-component-enemy",
    toolbar: false,
    report: {
        dataSource: { data: enemyGridData }, // Передаємо саме масив ворога!
        slice: {
            rows: [{ uniqueName: "Row" }],
            columns: [{ uniqueName: "Column" }],
            measures: [{ uniqueName: "Status", aggregation: "none" }]
        },
        options: {
            grid: { showGrandTotals: "off", showTotals: "off", showFilter: false, showHeaders: false }
        },
        tableSizes: {
            columns: [
                { idx: 0, width: 40 }, { idx: 1, width: 40 }, { idx: 2, width: 40 }, { idx: 3, width: 40 }, 
                { idx: 4, width: 40 }, { idx: 5, width: 40 }, { idx: 6, width: 40 }, { idx: 7, width: 40 },
                { idx: 8, width: 40 }, { idx: 9, width: 40 }, { idx: 10, width: 40 }
            ]
        }
    },
    customizeCell: handleCellCustomization
});

// Вибір кораблів кнопками
buttons.forEach((button) => { 
    button.addEventListener('click', () => { 
        currentSelectedShipButton = parseInt(button.getAttribute('data-size'));
        buttons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
    });
});

// Клік по повороту миші (зміна орієнтації)
window.addEventListener('contextmenu', function (e) { 
    e.preventDefault();
    isHorizontal = !isHorizontal;
});

// Клік на СВОЮ дошку (Розстановка)
pivot.on("cellclick", function (cellData) { 
    if (isBoardLocked) return; 

    if (cellData.type === "value") {
        let clickedRow = cellData.rows[0].caption;
        let clickedColumn = cellData.columns[0].caption;
        let r = parseInt(clickedRow);
        let c = columns.indexOf(clickedColumn);
        let clickedCell = gridData.find(item => item.Row === r && item.Column === clickedColumn);
        
        if (clickedCell && clickedCell.Status === 0) {
            setShip(r, c, currentSelectedShipButton, isHorizontal);
        }
    }
});

// Клік на дошку ВОРОГА (Стрільба)
pivotEnemy.on("cellclick", function (cellData) { 
    // Стріляти можна тільки якщо ми зафіксували свої кораблі і зараз наш хід
    if (!isBoardLocked || !isMyTurn) return;

    if (cellData.type === "value") {
        let clickedRow = parseInt(cellData.rows[0].caption);
        let clickedColumn = cellData.columns[0].caption;

        let targetCell = enemyGridData.find(item => item.Row === clickedRow && item.Column === clickedColumn);
        
        // Якщо в цю клітинку вже стріляли (статус влучання 3 або промаху 4) — ігноруємо
        if (targetCell.Status === 3 || targetCell.Status === 4) return;

        // Відправляємо постріл на сервер
        socket.emit('fire', { roomId: myRoomId, row: clickedRow, column: clickedColumn });
    }
});

function setShip(startRow, startColIndex, size, isHorizontal) { 
    if (shipRemaining[size] <= 0) return false;

    const shipCells = [];

    for (let i = 0; i < size; i++) { 
        const cell = isHorizontal ? getCell(startRow, columns[startColIndex + i]) : getCell(startRow + i, columns[startColIndex]);
        if (!cell) return false;
        shipCells.push(cell);
    }

    shipCells.forEach(cell => { cell.Status = 1; });

    shipCells.forEach(cell => {
        const r = cell.Row;
        const c = columns.indexOf(cell.Column);
        for (let dr = -1; dr <= 1; dr++) { 
            for (let dc = -1; dc <= 1; dc++) { 
                const neighbor = getCell(r + dr, columns[c + dc]);
                if (neighbor && neighbor.Status === 0) { 
                    neighbor.Status = 2;
                }
            }
        }
    });
    
    pivot.updateData({ data: gridData });
    shipRemaining[size]--;
}

function getCell(row, colName) {
    if (row < 1 || row > 10 || !colName) return undefined;
    return gridData.find(item => item.Row === row && item.Column === colName);
}

// Обробка натискання кнопки "Готово в бій!"
readyButton.addEventListener('click', () => {
    let totalShipsLeft = shipRemaining[1] + shipRemaining[2] + shipRemaining[3] + shipRemaining[4];
    
    if (totalShipsLeft > 0) {
        alert('Спочатку розставте всі кораблі!');
        return;
    }

    sendReadyStatus();

    isBoardLocked = true;
    readyButton.disabled = true;
    readyButton.innerText = 'Очікуємо суперника...';
    readyButton.style.opacity = '0.5';
});

// --- СЛУХАЧІ РЕЗУЛЬТАТІВ БОЮ ВІД СЕРВЕРА ---

// Оновлення черги ходу
socket.on('turn_update', (turnId) => {
    isMyTurn = (turnId === socket.id);
    if (isMyTurn) {
        readyButton.innerText = 'Ваш хід! Стріляйте!';
        readyButton.style.color = 'green';
        readyButton.style.opacity = '1';
    } else {
        readyButton.innerText = 'Хід суперника...';
        readyButton.style.color = 'red';
        readyButton.style.opacity = '0.7';
    }
});

// Результат твого пострілу (оновлюємо вороже поле)
socket.on('fire_result', (result) => {
    let target = enemyGridData.find(item => item.Row === result.row && item.Column === result.column);
    if (target) {
        target.Status = result.isHit ? 3 : 4;
        pivotEnemy.updateData({ data: enemyGridData });
    }
});

// Результат пострілу ворога по тобі (оновлюємо твоє поле)
socket.on('receive_shot', (result) => {
    let target = gridData.find(item => item.Row === result.row && item.Column === result.column);
    if (target) {
        target.Status = result.isHit ? 3 : 4;
        pivot.updateData({ data: gridData });
    }
});