const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

const games = {};

io.on('connection', (socket) => {
    console.log('Гравець підключився:', socket.id);

    socket.on('join_room', (roomId) => {
        if (!games[roomId]) {
            // Додаємо змінну turn, щоб знати, чий зараз хід
            games[roomId] = { players: [], boards: {}, turn: null };
        }

        if (games[roomId].players.length < 2) {
            socket.join(roomId);
            games[roomId].players.push(socket.id);
            socket.emit('joined', { playerId: socket.id, room: roomId });

            if (games[roomId].players.length === 2) {
                io.to(roomId).emit('game_ready', 'Обидва гравці на місці! Розставляйте кораблі.');
            }
        }
    });

    socket.on('submit_board', (data) => {
        const { roomId, board } = data;
        games[roomId].boards[socket.id] = board;

        if (Object.keys(games[roomId].boards).length === 2) {
            // Гра починається, перший хід віддаємо першому гравцеві
            games[roomId].turn = games[roomId].players[0];
            io.to(roomId).emit('start_shooting', 'Всі готові! Починаємо стріляти.');
            io.to(roomId).emit('turn_update', games[roomId].turn); // Повідомляємо, чий хід
        } else {
            socket.emit('waiting_for_opponent', 'Чекаємо, поки суперник розставить кораблі...');
        }
    });

    // Логіка пострілу
    socket.on('fire', (data) => {
        const { roomId, row, column } = data;
        const game = games[roomId];

        // Якщо зараз не хід цього гравця — ігноруємо
        if (game.turn !== socket.id) return;

        // Знаходимо суперника та його дошку
        const opponentId = game.players.find(id => id !== socket.id);
        const opponentBoard = game.boards[opponentId];

        // Шукаємо клітинку, в яку вистрілили
        let targetCell = opponentBoard.find(c => c.Row === row && c.Column === column);
        let isHit = false;

        if (targetCell) {
            // Якщо там корабель (статус 1)
            if (targetCell.Status === 1) {
                isHit = true;
                targetCell.Status = 3; // Змінюємо статус на "Влучання"
            } 
            // Якщо там вода (0) або буфер (2)
            else if (targetCell.Status === 0 || targetCell.Status === 2) {
                targetCell.Status = 4; // Змінюємо статус на "Промах"
            }

            // Відправляємо результати
            // 1. Тому, хто стріляв (щоб оновив радар)
            socket.emit('fire_result', { row, column, isHit });
            // 2. Тому, в кого стріляли (щоб оновив свою дошку)
            io.to(opponentId).emit('receive_shot', { row, column, isHit });

            // Передаємо хід (навіть якщо влучив, для простоти поки робимо чергу строго 1 через 1)
            // Якщо хочеш, щоб після влучання гравець стріляв ще раз - можна додати умову: if (!isHit) { game.turn = opponentId; }
            game.turn = opponentId;
            io.to(roomId).emit('turn_update', game.turn);
        }
    });
});

server.listen(3000, () => {
    console.log('Сервер запущено на порту 3000');
});