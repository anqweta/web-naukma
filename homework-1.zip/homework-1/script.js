
/* addNewProduct();

const container = document.querySelector('.shopping-list');

container.addEventListener('click', (event) => {
    const redButton = event.target.closest('.button-red');
    if (redButton) {
        changeCountOfProduct(redButton, 1);
    }

    const greenButton = event.target.closest('.button-green');
    if (greenButton) {
        changeCountOfProduct(greenButton, -1);
    }

    const productName = event.target.closest('.product__name');
    if (productName) {
        changeNameOfProduct(productName);
    }

    const deleteButton = event.target.closest('.button-delete');
    if (deleteButton) { 
        const productItem = deleteButton.closest('.list-item');
        if (productItem) {
            productItem.remove();
        }
    }

    const buyButton = event.target.closest('.button-buy');
    if (buyButton) {
        const productItem = buyButton.closest('.list-item');
        const currentDelBth = productItem.querySelector('.button-delete');
        const redButton = productItem.querySelector('.button-red');
        const greenButton = productItem.querySelector('.button-green');
        if (currentDelBth) {
            currentDelBth.remove();
            redButton.remove();
            greenButton.remove();
        }
    }

});


function changeCountOfProduct(button, count) {
    const parentDiv = button.closest('.inner__button');
    const paragraph = parentDiv.querySelector('.count-product');
    let currentCount = parseInt(paragraph.textContent);
    let newCount = currentCount + count;
    if (newCount > 0) {
        paragraph.textContent = newCount;
    }
}   


function changeNameOfProduct(currentParagraph) { 

    const inputElement = document.createElement('input');
    inputElement.type = 'text';
    inputElement.value = currentParagraph.textContent;
    currentParagraph.replaceWith(inputElement);
    inputElement.focus();

    inputElement.addEventListener('blur', (event) => { 
        if (inputElement.value.trim() !== '') {
            currentParagraph.textContent = inputElement.value;
        }
        inputElement.replaceWith(currentParagraph);
    });
    
    inputElement.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            if (inputElement.value.trim() !== '') {
                currentParagraph.textContent = inputElement.value;
            }
            inputElement.replaceWith(currentParagraph);
        }
    });
}


function addNewProduct() { 
    const addNewProductInput = document.getElementById('addNewProduct');
    const container = document.querySelector('.shopping-list'); 
    const sideBarContainer = document.getElementById('remaining');
    
    addNewProductInput.addEventListener('keydown', (event) => { 
        if (event.key === 'Enter') { 
            let productName = addNewProductInput.value.trim();

            if (productName === '') {
                return; 
            }

            const sideBarItem = `<div>${productName} <span>1</span></div>
            `;

            const newProductBlock = `
            <div class="list-item">
                <p class="product__name">${productName}</p>
                <div class="inner__button">
                    <button data-tooltip="tooltip" class="button-red">+</button>
                    <div class=""><p class="count-product">1</p></div>
                    <button data-tooltip="tooltip" class="button-green">-</button>
                </div>
                 <div class="inner__button">
            <button data-tooltip="tooltip" class="item__button button-delete">
              Видалити
            </button>
            <button data-tooltip="tooltip" class="item__button button-buy">
                Купити
            </button>
          </div>
            </div>
            `;
            sideBarContainer.insertAdjacentHTML('beforeend', sideBarItem);
            container.insertAdjacentHTML('beforeend', newProductBlock);    
            addNewProductInput.value = '';
        }
    });
}

*/

let products = JSON.parse(localStorage.getItem('shoppingList')) || [
    {
        id: 1,
        name: 'Помідори',
        count: 2,
        isBought: false
    },
    {
        id: 2,
        name: 'Печиво',
        count: 2,
        isBought: false
    },
    {   
        id: 3,
        name: 'Сир',
        count: 1,
        isBought: true
    }
]

let nextId = 4;

const container = document.querySelector('.shopping-list');
const remainContainer = document.getElementById('remaining');
const boughtContainer = document.getElementById('bought');

renderProducts();
addNewProduct();

container.addEventListener('click', (event) => {
    const productId = event.target.closest('[data-id]').dataset.id;
    

    const foundProduct = products.find(product => product.id === parseInt(productId));

    const redButton = event.target.closest('.button-red');
    if (redButton) {
            foundProduct.count += 1;
    }

    const greenButton = event.target.closest('.button-green');
    if (greenButton) {
            if (foundProduct.count > 0) {
                foundProduct.count -= 1;
            }
    }

    const deleteButton = event.target.closest('.button-delete');
    if (deleteButton) { 
        products = products.filter(product => product.id !== parseInt(productId));
    }

    const changeNameButton = event.target.closest('.product__name');
    if (changeNameButton) {
        changeNameOfProduct(productId);
        return;
    }

    const buyButton = event.target.closest('.button-buy');
    if (buyButton) { 
        foundProduct.isBought = true;
    }

    renderProducts();
});

function changeNameOfProduct(productId) { 

    const foundProduct = products.find(product => product.id === parseInt(productId));
    const inputElement = document.createElement('input');
    const productCard = container.querySelector(`[data-id="${productId}"]`);
    const currentParagraph = productCard.querySelector('.product__name');

    inputElement.type = 'text';
    inputElement.value = foundProduct.name;
    currentParagraph.replaceWith(inputElement);
    inputElement.focus();

    inputElement.addEventListener('blur', (event) => { 
        if (inputElement.value.trim() !== '') {
            foundProduct.name = inputElement.value;
        }
        inputElement.replaceWith(currentParagraph);
        renderProducts();
    });
    
    inputElement.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            if (inputElement.value.trim() !== '') {
                foundProduct.name = inputElement.value;
            }
            inputElement.replaceWith(currentParagraph);
            renderProducts();
        }
    });
    
}

function addNewProduct() { 
    const addNewProductInput = document.getElementById('addNewProduct');
    const addButton = document.getElementById('addButton');
    const addItem = event => {if (addNewProductInput.value.trim() !== '') {
            products.push({
                id: nextId,
                name: addNewProductInput.value.trim(),
                count: 1,
                isBought: false
            });
            addNewProductInput.value = '';
            nextId++;
            renderProducts();
           }}
    addNewProductInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            addItem();
        }
    });
    addButton.addEventListener('click', () => {
        addItem();
    });
        renderProducts();
}

function renderProducts() { 
    localStorage.setItem('shoppingList', JSON.stringify(products));
    const containerProductsDel = document.querySelectorAll('.list-item');
    remainContainer.innerHTML = '';
    boughtContainer.innerHTML = '';
    containerProductsDel.forEach(product => { 
        product.remove();
    });
    products.forEach(product => { 
        if (!product.isBought) {
            const productBlock = `
            <div class="list-item" data-id="${product.id}">
          <p class="product__name">${product.name}</p>
          <div class="inner__button">
            <button data-tooltip="tooltip" class="button-red">+</button>
            <div class=""><p class="count-product">${product.count}</p></div>
            <button data-tooltip="tooltip" class="button-green">-</button>
          </div>
          <div class="inner__button">
              <button data-tooltip="tooltip" class="item__button button-buy">Купити</button>
            <button data-tooltip="tooltip" class="item__button button-delete">Видалити
            </button>
          </div>
        
        </div>`
            const sideBarItem = `<div>${product.name} <span>${product.count}</span></div>
            `;
            remainContainer.insertAdjacentHTML('beforeend', sideBarItem);
            container.insertAdjacentHTML('beforeend', productBlock); 
        } else {
            const productBlock = `<div class="list-item" data-id="${product.id}">
          <p class="product__name">${product.name}</p>
          <div><p class="count-product">${product.count}</p></div>
          <button data-tooltip="tooltip" class="item__button">Куплено!</button>
        </div>`
            const sideBarItem = `<div>${product.name} <span>${product.count}</span></div>
            `;
            boughtContainer.insertAdjacentHTML('beforeend', sideBarItem);
            container.insertAdjacentHTML('beforeend', productBlock); 
        }
    });
}